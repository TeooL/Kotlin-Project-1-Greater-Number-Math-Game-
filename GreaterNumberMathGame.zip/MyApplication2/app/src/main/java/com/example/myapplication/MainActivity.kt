package com.example.myapplication

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private var ran1: Int = 0
    private var ran2: Int = 0
    private var num_score = 0;
    private var num_strikes = 0;
    private var endPhase = false;

    lateinit var main: LinearLayout
    lateinit var score: TextView
    lateinit var strikes: TextView
    lateinit var infoText: TextView
    lateinit var box1: TextView
    lateinit var box2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ran1 = randomize(1, 100)
        ran2 = randomize(1, 100)
        while (ran1 == ran2) {
            ran1 = randomize(1, 100)
        }

        main = findViewById(R.id.main)
        score = findViewById(R.id.Score)
        strikes = findViewById(R.id.Strikes)
        val start: Button = findViewById(R.id.Start_Restart)
        infoText = findViewById(R.id.InformationText)
        box1 = findViewById(R.id.box1)
        box2 = findViewById(R.id.box2)

        start.setOnClickListener {
            start.text = getString(R.string.restart)
            infoText.text = getString(R.string.tap_the_larger_number)
            box1.text = "$ran1"
            box2.text = "$ran2"

            start.setOnClickListener {     //Clicking Restart
                num_score = 0
                num_strikes = 0
                score.text = "Score: $num_score"
                strikes.text = "Strikes: $num_strikes"
                main.setBackgroundColor(Color.YELLOW)
                score.setTextColor(Color.BLACK)
                strikes.setTextColor(Color.BLACK)
                ran1 = randomize(1, 100)
                ran2 = randomize(1, 100)
                while (ran1 == ran2) {
                    ran1 = randomize(1, 100)
                }
                box1.text = "$ran1"
                box2.text = "$ran2"
                endPhase = false
                box1.isClickable = true
                box2.isClickable = true
            }
            box1.setOnClickListener {
                if (isGreater(ran1, ran2)) {
                    correctView()
                    checkWinLoss()
                    disableBoxes()
                } else {
                    incorrectView()
                    checkWinLoss()
                    disableBoxes()
                }
            }

            box2.setOnClickListener {
                if (isGreater(ran2, ran1)) {
                    correctView()
                    checkWinLoss()
                    disableBoxes()
                } else {
                    incorrectView()
                    checkWinLoss()
                    disableBoxes()
                }
            }
        }
    }

    private fun randomize(min: Int, max: Int) :Int {
        return Random.nextInt(max) + min
    }

    private fun isGreater(this_val: Int, other_val: Int) :Boolean{
        return (this_val > other_val)
    }

    private fun correctView(){
        num_score++
        score.text = "Score: $num_score"
        score.setTextColor(Color.YELLOW)
        strikes.setTextColor(Color.BLACK)
        main.setBackgroundColor(Color.GREEN)
        ran1 = randomize(1,100)
        ran2 = randomize(1,100)
        while (ran1 == ran2){
            ran1 = randomize(1,100)
        }
        box1.text = "$ran1"
        box2.text = "$ran2"
    }

    private fun incorrectView(){
        num_strikes++
        strikes.text = "Strikes: $num_strikes"
        strikes.setTextColor(Color.YELLOW)
        score.setTextColor(Color.BLACK)
        main.setBackgroundColor(Color.RED)
        ran1 = randomize(1,100)
        ran2 = randomize(1,100)
        while (ran1 == ran2){
            ran1 = randomize(1,100)
        }
        box1.text = "$ran1"
        box2.text = "$ran2"
    }
    private fun checkWinLoss(){
        if (num_score == 10){
            endPhase = true
            winScreen()
            val winToast : Toast = Toast.makeText(this,getString(R.string.congrats_you_won),Toast.LENGTH_SHORT)
            winToast.show()
        }
        else if (num_strikes == 3){
            endPhase = true
            loseScreen()
            val loseToast : Toast = Toast.makeText(this,getString(R.string.sorry_you_lost),Toast.LENGTH_SHORT)
            loseToast.show()
        }
    }
    private fun winScreen(){
        score.setTextColor(Color.GREEN)
        strikes.setTextColor(Color.BLACK)
        main.setBackgroundColor(Color.YELLOW)
        infoText.text = getString(R.string.tap_restart_to_play_again)
        box1.text = ""
        box2.text = ""
    }
    private fun loseScreen(){
        score.setTextColor(Color.BLACK)
        strikes.setTextColor(Color.RED)
        main.setBackgroundColor(Color.YELLOW)
        infoText.text = getString(R.string.tap_restart_to_play_again)
        box1.text = ""
        box2.text = ""
    }
    private fun disableBoxes(){
        if (endPhase){
            box1.isClickable = false
            box2.isClickable = false
        }
    }
}